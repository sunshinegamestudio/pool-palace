#!/bin/sh
java  -jar Pool_Palace.jar
        